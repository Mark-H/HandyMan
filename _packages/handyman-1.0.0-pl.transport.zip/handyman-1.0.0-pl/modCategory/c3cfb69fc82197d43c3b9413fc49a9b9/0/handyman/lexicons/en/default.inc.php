<?php

$_lang['handyman'] = 'HandyMan';
$_lang['handyman.view_context_start'] = 'View Website';
/*
$_lang['setting_handyman.core_path'] = 'Core Path';
$_lang['setting_handyman.core_path_desc'] = 'The absolute path to the core/components/handyman/ directory. Leave empty to let HandyMan calculate the default.';
$_lang['setting_handyman.path'] = 'Path';
$_lang['setting_handyman.path_desc'] = 'The absolute path to the handyman/ directory. Leave empty to let HandyMan use the default of the /handyman/ directory under the MODX base_path.';
$_lang['setting_handyman.url'] = 'URL';
$_lang['setting_handyman.url_desc'] = 'The web accessible URL to the handyman/ directory. Leave empty to let HandyMan use the default of the /handyman/ directory under the MODX base_url.';
$_lang['setting_handyman.templates'] = 'Templates';
$_lang['setting_handyman.templates_desc'] = 'The templates to use. HandyMan (at this point) only comes with one default template "default" which uses jQuery Mobile, but this may be overridden. If a specific template does not exist in a non-default theme it will fall back to the default set.';
$_lang['setting_handyman.theme'] = 'Theme';
$_lang['setting_handyman.theme_desc'] = 'The theme, existing of CSS and image files, to use. HandyMan (at this point) only comes with one default template "default" which is a modified version of the jQuery Mobile theme, but this may be overridden.';
*/
?>
